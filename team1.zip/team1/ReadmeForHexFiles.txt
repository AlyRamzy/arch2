1-one operand and two operand instructions don't deal with memory so there is no .mem file for them 
2-.mem files for memory instructions is in Memory Test Case floder
3- .mem file for branch instructions s in HexMemoryForBranch folder
 